// src/content/blog/hello.md
---
title: 'はじめまして！'
cover: '/images/image1.jpg'
created: '2025-06-01'
updated: '2025-06-01'
---

## はじめまして！

こんにちは、はじめまして！この度、新しくブログを始めることにしました。
最初の投稿として、簡単に自己紹介をさせていただきます。


...(以下省略)